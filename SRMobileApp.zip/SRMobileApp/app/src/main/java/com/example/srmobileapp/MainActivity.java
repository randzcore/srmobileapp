package com.example.srmobileapp;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    ListView lvarea;
    ArrayList<HashMap<String, String>> arealist;
    Spinner sploc;
    String userid,name,phone;
    Dialog myDialogCart,myDialogHistory;
    ArrayList<HashMap<String, String>> cartlist;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lvarea = findViewById(R.id.listviewArea);
        sploc = findViewById(R.id.spinner);
        //user
//        Intent intent = getIntent();
//        Bundle bundle = intent.getExtras();
//        userid = bundle.getString("userid");
//        name = bundle.getString("name");
//        phone = bundle.getString("phone");
        loadArea(sploc.getSelectedItem().toString());
        lvarea.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent intent = new Intent(MainActivity.this, AreaActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("area",arealist.get(position).get("area"));
                bundle.putString("name",arealist.get(position).get("name"));
                bundle.putString("phone",arealist.get(position).get("phone"));
                bundle.putString("address",arealist.get(position).get("address"));
                bundle.putString("location",arealist.get(position).get("location"));
//                bundle.putString("userid",userid);
//                bundle.putString("userphone",phone);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });

        sploc.setSelection(0,false);
        sploc.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                loadArea(sploc.getSelectedItem().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    private void loadArea(final String loc) {
        class loadArea extends AsyncTask<Void,Void,String>{

            @Override
            protected String doInBackground(Void... voids) {
                HashMap<String,String> hashMap = new HashMap<>();
                hashMap.put("location",loc);
                RequestHandler rh = new RequestHandler();
                arealist = new ArrayList<>();
                String s = rh.sendPostRequest
                        ("https://srmobileapp.000webhostapp.com/php/load_area.php",hashMap);
                return s;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                //Toast.makeText(MainActivity.this, s, Toast.LENGTH_LONG).show();
                arealist.clear();
                    try{
                        JSONObject jsonObject = new JSONObject(s);
                        JSONArray areaarray = jsonObject.getJSONArray("area");
                        Log.e("RANDY",jsonObject.toString());
                        for (int i=0;i<areaarray.length();i++){
                            JSONObject c = areaarray.getJSONObject(i);
                            String rid = c.getString("area");
                            String rname = c.getString("name");
                            String rphone = c.getString("phone");
                            String raddress = c.getString("address");
                            String rlocation = c.getString("location");
                            HashMap<String,String> arealisthash = new HashMap<>();
                            arealisthash.put("area",rid);
                            arealisthash.put("name",rname);
                            arealisthash.put("phone",rphone);
                            arealisthash.put("address",raddress);
                            arealisthash.put("location",rlocation);
                            arealist.add(arealisthash);
                        }
                    }catch (final JSONException e){
                        Log.e("JSONERROR",e.toString());
                    }

                    ListAdapter adapter = new SimpleAdapter(
                            MainActivity.this, arealist,
                            R.layout.cust_list_area, new String[]
                            {"name","phone","address","location"}, new int[]
                            {R.id.textView,R.id.textView2,R.id.textView3,R.id.textView4});
                    lvarea.setAdapter(adapter);
                }

        }
        loadArea loadArea = new loadArea();
        loadArea.execute();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.mycart:
                loadCartWindow();
                return true;
            case R.id.myprofile:
                Intent intent = new Intent(MainActivity.this,ProfileActivity.class);
                startActivity(intent);
                return true;
            case R.id.logout:
                intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
                return true;
            case R.id.about:
                intent = new Intent(MainActivity.this, AboutActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //cart
    private void loadCartWindow() {
        myDialogCart = new Dialog(this, android.R.style.Theme_DeviceDefault_Light_Dialog_NoActionBar_MinWidth);//Theme_DeviceDefault_Dialog_NoActionBar
        myDialogCart.setContentView(R.layout.cart_window);
        myDialogCart.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
//        ListView lvcart = myDialogCart.findViewById(R.id.lvmycart);
//        TextView tvorderid = myDialogCart.findViewById(R.id.textOrderId);
//        Log.e("RANDY","SIZE:"+cartlist.size());
//        lvcart.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
//            @Override
//            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
//                dialogDeleteFood(position);
//                return false;
//            }
//        });
//        tvorderid.setText(cartlist.get(1).get("orderid"));
        myDialogCart.show();

    }

    private void dialogDeleteFood(final int position) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setTitle("Delete Song "+cartlist.get(position).get("songtitle")+"?");
        alertDialogBuilder
                .setMessage("Are you sure")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        // Toast.makeText(MainActivity.this, cartlist.get(position).get("songtitle"), Toast.LENGTH_SHORT).show();
                        deleteCartFood(position);
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void deleteCartFood(final int position) {
        class DeleteCartFood extends AsyncTask<Void,Void,String>{

            @Override
            protected String doInBackground(Void... voids) {
                String songid = cartlist.get(position).get("songid");
                HashMap<String,String> hashMap = new HashMap<>();
                hashMap.put("songid",songid);
                hashMap.put("userid",userid);
                RequestHandler requestHandler = new RequestHandler();
                String s = requestHandler.sendPostRequest("http://srmobileapp.000webhostapp.com/php/delete_cart.php",hashMap);
                return s;
            }
            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                if (s.equalsIgnoreCase("success")){
                    myDialogCart.dismiss();
                    loadCartData();
                    Toast.makeText(MainActivity.this, "Success", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this, "Failed", Toast.LENGTH_SHORT).show();
                }
            }
        }
        DeleteCartFood deleteCartFood = new DeleteCartFood();
        deleteCartFood.execute();
    }


    private void loadCartData() {
        class LoadCartData extends AsyncTask<Void,Void,String>{

            @Override
            protected String doInBackground(Void... voids) {
                HashMap<String,String> hashMap = new HashMap<>();
                hashMap.put("userid",userid);
                RequestHandler rh = new RequestHandler();
                String s = rh.sendPostRequest("http://srmobileapp.000webhostapp.com/php/load_cart.php",hashMap);
                return s;
            }

            @Override
            protected void onPostExecute(String s) {
                cartlist.clear();
                try{
                    JSONObject jsonObject = new JSONObject(s);
                    JSONArray cartarray = jsonObject.getJSONArray("cart");

                    for (int i=0;i<cartarray .length();i++) {
                        JSONObject c = cartarray .getJSONObject(i);
                        String jfid = c.getString("songid");
                        String jfn = c.getString("songtitle");
                        String jst = c.getString("status");
                        String joid = c.getString("orderid");
                        HashMap<String,String> cartlisthash = new HashMap<>();
                        cartlisthash .put("songid",jfid);
                        cartlisthash .put("songtitle",jfn);
                        cartlisthash .put("status",jst);
                        cartlisthash .put("orderid",joid);
                        cartlist.add(cartlisthash);

                    }
                }catch (JSONException e){}
                super.onPostExecute(s);
                loadCartWindow();


            }
        }
        LoadCartData loadCartData = new LoadCartData();
        loadCartData.execute();
    }
}
