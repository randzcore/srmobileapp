package com.example.srmobileapp;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.hardware.Camera;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class AreaActivity extends AppCompatActivity {
TextView tvrname,tvrphone,tvraddress,tvrloc;
ImageView imgArea;
ListView lvsong;
ArrayList<HashMap<String, String>> songlist;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_area);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        String areaid = bundle.getString("area");
        String rname = bundle.getString("name");
        String rphone = bundle.getString("phone");
        String raddress = bundle.getString("address");
        String rlocation = bundle.getString("location");
        initView();
        tvrname.setText(rname);
        tvraddress.setText(raddress);
        tvrphone.setText(rphone);
        tvrloc.setText(rlocation);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Picasso.with(this).load("https://srmobileapp.000webhostapp.com/images/"+areaid+".jpg")
                .memoryPolicy(MemoryPolicy.NO_CACHE).networkPolicy(NetworkPolicy.NO_CACHE)
                .fit().into(imgArea);

        lvsong.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                showSongDetail(position);
            }
        });
        loadSongs(areaid);

    }

    private void showSongDetail(int p) {
            final Dialog myDialogWindow = new Dialog(this, android.R.style.Theme_DeviceDefault_Light_Dialog_NoActionBar_MinWidth);//Theme_DeviceDefault_Dialog_NoActionBar
            myDialogWindow.setContentView(R.layout.dialog_window);
            myDialogWindow.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            TextView tvfname;
            ImageView imgsong = myDialogWindow.findViewById(R.id.imageViewSong);
            Button btnrequest = myDialogWindow.findViewById(R.id.button2);
            tvfname= myDialogWindow.findViewById(R.id.textView12);
            tvfname.setText(songlist.get(p).get("songtitle"));
            String songid =(songlist.get(p).get("songid"));
            final String songtitle = songlist.get(p).get("songtitle");
            btnrequest.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialogRequest(songtitle,"available");

                }
            });

//            List<String> list = new ArrayList<String>();
//            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
//                android.R.layout.simple_spinner_item, list);
//            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//            spquan.setAdapter(dataAdapter);
//
            Picasso.with(this).load("https://srmobileapp.000webhostapp.com/songimages/"+songid+".jpg")
                .memoryPolicy(MemoryPolicy.NO_CACHE).networkPolicy(NetworkPolicy.NO_CACHE)
                .fit().into(imgsong);
            myDialogWindow.show();
    }

    private void dialogRequest(final String fn, final String q) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setTitle("Request "+fn+ " with status "+q);

        alertDialogBuilder
                .setMessage("Are you sure")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Toast.makeText(AreaActivity.this, "You have requested this song and wait for the song to be played", Toast.LENGTH_LONG).show();

                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void loadSongs(final String areaid) {
        class loadSong extends AsyncTask<Void,Void,String>{

            @Override
            protected String doInBackground(Void... voids) {
                HashMap<String,String> hashMap = new HashMap<>();
                hashMap.put("areaid",areaid);
                RequestHandler requestHandler = new RequestHandler();
                String s = requestHandler.sendPostRequest("https://srmobileapp.000webhostapp.com/php/load_song.php",hashMap);
                return s;
            }
            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                songlist.clear();
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    JSONArray songarray = jsonObject.getJSONArray("song");
                    for (int i = 0; i < songarray.length(); i++) {
                        JSONObject c = songarray.getJSONObject(i);
                        String jsid = c.getString("songid");
                        String jstitle = c.getString("songtitle");
                        HashMap<String,String> songlisthash = new HashMap<>();
                        songlisthash.put("songid",jsid);
                        songlisthash.put("songtitle",jstitle);
                        songlist.add(songlisthash);
                    }
                }catch(JSONException e){}
                ListAdapter adapter = new SimpleAdapter(
                        AreaActivity.this, songlist,
                        R.layout.song_list, new String[]
                        {"songtitle","songprice","songstatus"}, new int[]
                        {R.id.textView,R.id.textView2,R.id.textView3});
                lvsong.setAdapter(adapter);

            }
        }
        loadSong loadSong = new loadSong();
        loadSong.execute();
    }

    private void initView() {
        imgArea = findViewById(R.id.imageView3);
        tvrname = findViewById(R.id.textView6);
        tvrphone = findViewById(R.id.textView7);
        tvraddress = findViewById(R.id.textView8);
        tvrloc = findViewById(R.id.textView9);
        lvsong = findViewById(R.id.listviewsong);
        songlist = new ArrayList<>();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent = new Intent(AreaActivity.this,MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                startActivity(intent);
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
